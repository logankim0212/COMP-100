﻿using System;
/*
 * =========================      Test #1 Fall 2017      =================
 * 
 * Name: Logan Kim
 * Student ID: 300-973-239
 *
 * Question 1d.
 * 10 Marks.
 *
 * Write a program that displays your name, student number and your 
 * program. Although your information will be different from the sample 
 * output, you must match the format exactly.
 * 
 * [Solution: Question1D]
 */
namespace Question_1d
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("#######################################");
            Console.WriteLine("#   Logan Kim                         #");
            Console.WriteLine("#   300-973-239                       #");
            Console.WriteLine("#   Software Enginnering Technology   #");
            Console.WriteLine("#######################################");
        }
    }
}
